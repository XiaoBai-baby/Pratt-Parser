#include <iostream>
#include <unordered_map>
#include <string>
#include <vector>
#include <sstream>
#include <stdexcept>
#include <cmath>

class Expression;

enum class Token {
    Atom,
    Op,
    Eof,
};

class Lexer {
public:
    Lexer(const std::string& input) {
        for (char c : input) {
            if (!isspace(c)) {
                tokens.push_back(c);
            }
        }
        std::reverse(tokens.begin(), tokens.end());
    }

    char next() {
        if (tokens.empty()) {
            return '\0'; // Eof
        }
        char token = tokens.back();
        tokens.pop_back();
        return token;
    }

    char peek() {
        return tokens.empty() ? '\0' : tokens.back();
    }

private:
    std::vector<char> tokens;
};

class Expression {
public:
    enum class Type {
        Atom,
        Operation,
    };

    Expression(char atom) : type(Type::Atom), atomValue(atom) {}
    Expression(char operation, std::vector<Expression> operands)
        : type(Type::Operation), operationValue(operation), operandValues(operands) {}

    static Expression from_str(const std::string& input) {
        Lexer lexer(input);
        return parse_expression(lexer, 0.0);
    }

    bool is_asign() const {
        if (type == Type::Operation && operationValue == '=') {
            char var_name = operandValues.front().atomValue;
            return (isalpha(var_name)) ? var_name : throw std::runtime_error("Not a variable name");
        }
        return false;
    }

    float eval(const std::unordered_map<char, float>& variables) const {
        if (type == Type::Atom) {
            if (isdigit(atomValue)) {
                return atomValue - '0';
            } else {
                auto it = variables.find(atomValue);
                if (it != variables.end()) {
                    return it->second;
                } else {
                    throw std::runtime_error("Undefined variable");
                }
            }
        } else {
            float lhs = operandValues.front().eval(variables);
            float rhs = operandValues.back().eval(variables);
            switch (operationValue) {
                case '+': return lhs + rhs;
                case '-': return lhs - rhs;
                case '*': return lhs * rhs;
                case '/': return lhs / rhs;
                case '^': return std::pow(lhs, rhs);
                case '√': return std::pow(lhs, 1.0f / rhs);
                default: throw std::runtime_error("Bad operator");
            }
        }
    }

private:
    static Expression parse_expression(Lexer& lexer, float min_bp) {
        char first_token = lexer.next();
        Expression lhs(first_token);

        while (true) {
            char op = lexer.peek();
            if (op == '\0' || op == ')') {
                break;
            }

            auto [l_bp, r_bp] = infix_binding_power(op);
            if (l_bp < min_bp) {
                break;
            }

            lexer.next();
            Expression rhs = parse_expression(lexer, r_bp);
            lhs = Expression(op, {lhs, rhs});
        }
        return lhs;
    }

    static std::pair<float, float> infix_binding_power(char op) {
        switch (op) {
            case '=': return {0.2f, 0.1f};
            case '+':
            case '-': return {1.0f, 1.1f};
            case '*':
            case '/': return {2.0f, 2.1f};
            case '^':
            case '√': return {3.1f, 3.0f};
            default: throw std::runtime_error("bad op");
        }
    }

    Type type;
    char atomValue;
    char operationValue;
    std::vector<Expression> operandValues;
};

int main() {
    std::unordered_map<char, float> variables;
    while (true) {
        std::cout << ">> ";
        std::cout.flush();
        std::string input;
        std::getline(std::cin, input);
        if (input == "exit") {
            break;
        }
        Expression expr = Expression::from_str(input);
        if (expr.is_asign()) {
            // Handle assignment
            // ...
            continue;
        }
        float value = expr.eval(variables);
        std::cout << value << std::endl;
    }
}