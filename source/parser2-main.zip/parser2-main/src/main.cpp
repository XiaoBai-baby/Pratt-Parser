#include <iostream>
#include <unordered_map>
#include <string>
#include <vector>
#include <sstream>
#include <stdexcept>
#include <cmath>

class Expression;

enum class Token {
    Atom,
    Op,
    Eof,
};

class Lexer {
public:
    Lexer(const std::string &input) {
        for (char c : input) {
            if (!isspace(c)) {
                if (isalnum(c)) {
                    tokens.push_back(Token::Atom);
                } else {
                    tokens.push_back(Token::Op);
                }
                tokenChars.push_back(c);
            }
        }
        std::reverse(tokens.begin(), tokens.end());
        std::reverse(tokenChars.begin(), tokenChars.end());
    }

    Token next() {
        if (tokens.empty()) {
            return Token::Eof;
        }
        Token token = tokens.back();
        tokens.pop_back();
        return token;
    }

    Token peek() const {
        return tokens.empty() ? Token::Eof : tokens.back();
    }

    char currentChar() const {
        return tokenChars.empty() ? '\0' : tokenChars.back();
    }

private:
    std::vector<Token> tokens;
    std::vector<char> tokenChars;
};

class Expression {
public:
    enum class Type {
        Atom,
        Operation,
    };

    Expression(char atom) : type(Type::Atom), atomValue(atom) {}

    Expression(char operation, const std::vector<Expression> &operands)
        : type(Type::Operation), operationValue(operation), operands(operands) {}

    static Expression fromString(const std::string &input) {
        Lexer lexer(input);
        return parseExpression(lexer, 0.0);
    }

    bool isAssignment() const {
        if (type == Type::Operation && operationValue == '=') {
            char varName = operands[0].atomValue;
            return isalpha(varName);
        }
        return false;
    }

    char getVariableName() const {
        return operands[0].atomValue;
    }

    const Expression& getRightHandSide() const {
        return operands[1];
    }

    float eval(const std::unordered_map<char, float> &variables) const {
        if (type == Type::Atom) {
            if (isdigit(atomValue)) {
                return atomValue - '0';
            } else {
                return variables.at(atomValue);
            }
        } else if (type == Type::Operation) {
            float lhs = operands[0].eval(variables);
            float rhs = operands[1].eval(variables);
            switch (operationValue) {
                case '+': return lhs + rhs;
                case '-': return lhs - rhs;
                case '*': return lhs * rhs;
                case '/': return lhs / rhs;
                case '^': return std::pow(lhs, rhs);
                case '√': return std::pow(lhs, 1.0f / rhs);
                default: throw std::runtime_error("Bad operator");
            }
        }
        throw std::runtime_error("Invalid expression");
    }

private:
    static Expression parseExpression(Lexer &lexer, float minBP) {
        Expression lhs = parseAtom(lexer);
        while (true) {
            Token opToken = lexer.peek();
            if (opToken == Token::Eof || opToken == Token::Op) {
                break;
            }

            char op = lexer.currentChar();
            float lBP, rBP;
            std::tie(lBP, rBP) = infixBindingPower(op);
            if (lBP < minBP) {
                break;
            }
            lexer.next(); // consume the operator
            Expression rhs = parseExpression(lexer, rBP);
            lhs = Expression(op, {lhs, rhs});
        }
        return lhs;
    }

    static Expression parseAtom(Lexer &lexer) {
        Token token = lexer.next();
        if (token == Token::Atom) {
            return Expression(lexer.currentChar());
        } else if (token == Token::Op && lexer.currentChar() == '(') {
            Expression expr = parseExpression(lexer, 0.0);
            lexer.next(); // consume ')'
            return expr;
        }
        throw std::runtime_error("Bad token");
    }

    static std::pair<float, float> infixBindingPower(char op) {
        switch (op) {
            case '=': return {0.2f, 0.1f};
            case '+': case '-': return {1.0f, 1.1f};
            case '*': case '/': return {2.0f, 2.1f};
            case '^': case '√': return {3.1f, 3.0f};
            default: throw std::runtime_error("Bad operator");
        }
    }

    Type type;
    char atomValue;
    char operationValue;
    std::vector<Expression> operands;
};

int main() {
    std::unordered_map<char, float> variables;
    while (true) {
        std::cout << ">> ";
        std::cout.flush();
        std::string input;
        std::getline(std::cin, input);
        if (input == "exit") {
            break;
        }
        Expression expr = Expression::fromString(input);
        if (expr.isAssignment()) {
            char varName = expr.getVariableName();
            float value = expr.getRightHandSide().eval(variables);
            variables[varName] = value;
            continue;
        }
        float value = expr.eval(variables);
        std::cout << value << std::endl;
    }
    return 0;
}