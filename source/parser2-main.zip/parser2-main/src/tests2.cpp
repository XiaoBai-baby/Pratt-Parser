#include <string>
#include <cassert>
#include <iostream>

class Expression {
public:
    static Expression from_str(const std::string& str);
    std::string to_string() const;
};

void test_1() {
    Expression expression = Expression::from_str("1");
    assert(expression.to_string() == "1");
}

void test_2() {
    Expression expression = Expression::from_str("1 + 2 * 3");
    assert(expression.to_string() == "(+ 1 (* 2 3))");
}

void test_3() {
    Expression expression = Expression::from_str("a * 2 * b");
    assert(expression.to_string() == "(* (* a 2) b)");
}

void test_4() {
    Expression expression = Expression::from_str("a + b * 2 * c + a / 4");
    assert(expression.to_string() == "(+ (+ a (* (* b 2) c)) (/ a 4))");
}

void test_5() {
    Expression expression = Expression::from_str("2 + b * 5 - 3 / 5 + 5 - 3");
    assert(expression.to_string() == "(- (+ (- (+ 2 (* b 5)) (/ 3 5)) 5) 3)");
}

void test_6() {
    Expression expression = Expression::from_str("(2 + b) * 5");
    assert(expression.to_string() == "(* (+ 2 b) 5)");
}

void test_7() {
    Expression expression = Expression::from_str("(((a)))");
    assert(expression.to_string() == "a");
}

/*
void test_8() {
    Expression expression = Expression::from_str("a + b * 2 * (c + a) / 4");
    assert(expression.to_string() == "(+ a (/ (* (* b 2) (+ c a)) 4));
}

void test_9() {
    Expression expression = Expression::from_str("a + b * c ^ 4");
    std::cout << expression.to_string() << std::endl;
    assert(expression.to_string() == "(+ a (* b (^ c 4)))");
}

void test_10() {
    Expression expression = Expression::from_str("a + 2 √ 4 * b");
    std::cout << expression.to_string() << std::endl;
    assert(expression.to_string() == "(+ a (* (√ 2 4) b))");
}

void test_11() {
    Expression expression = Expression::from_str("a + 2 √ (4 * b)");
    std::cout << expression.to_string() << std::endl;
    assert(expression.to_string() == "(+ a (√ 2 (* 4 b)))");
}

void test_12() {
    Expression expression = Expression::from_str("a ^ b ^ 2");
    std::cout << expression.to_string() << std::endl;
    assert(expression.to_string() == "(^ a (^ b 2))");
}

void test_13() {
    Expression expression = Expression::from_str("a.b.c.d");
    std::cout << expression.to_string() << std::endl;
    assert(expression.to_string() == "(. (. (. a b) c) d)");
}
*/